## How to use Pycharm IDE more efficiently

1. Download Pycharm via this [link](https://www.jetbrains.com/pycharm/download/#section=windows).
2. Setting of **hard wrap**: Files -> Settings -> Editor -> Code Style -> Hard wrap at 180 (optional) columns.
3. Setting of python script **template**: Files -> Settings -> Editor -> File and Code Templates -> Files -> **Python Script**.
4. [Setting of remote host](https://www.cnblogs.com/xiongmao-cpp/p/7856596.html).
5. [Free use of Pycharm Professional with **student identity**].(https://blog.csdn.net/nima1994/article/details/78988595).