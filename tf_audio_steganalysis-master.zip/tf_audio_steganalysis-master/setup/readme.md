## Needed packages
+ numpy
+ pandas
+ scipy
+ matplotlib
+ tensorflow-gpu>=1.3
+ scikit-learn
+ scikit-image
+ librosa
+ filetype
+ virtualenv
+ jupyter

open command and input "pip install -r requirement.txt"