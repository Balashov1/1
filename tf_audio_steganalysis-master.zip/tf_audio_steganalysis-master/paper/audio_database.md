### Audio Database

+ [Google AudioSet](https://research.google.com/audioset/download.html)
+ [Million Song Dataset](https://labrosa.ee.columbia.edu/millionsong/?spm=5176.11156381.0.0.1d7b3dbcBhRWE3)
+ [LibriSpeech ASR corpus](http://www.openslr.org/12/?spm=5176.11156381.0.0.1d7b3dbcBhRWE3)
+ [Analytics Vidhya](https://datahack.analyticsvidhya.com/contest/practice-problem-urban-sound-classification/?spm=5176.11156381.0.0.1d7b3dbcBhRWE3)
+ [TIMIT Acoustic-Phonetic Continuous Speech Corpus](https://catalog.ldc.upenn.edu/LDC93S1)
+ [Lakh MIDI Dataset](https://colinraffel.com/projects/lmd/)
+ [VoxCeleb](http://www.robots.ox.ac.uk/~vgg/data/voxceleb/)

### Audio Download Website
+ [51ape](http://www.51ape.com/)
+ [Wavy - Royalty-free curated sounds](http://wavy.audio/)
  