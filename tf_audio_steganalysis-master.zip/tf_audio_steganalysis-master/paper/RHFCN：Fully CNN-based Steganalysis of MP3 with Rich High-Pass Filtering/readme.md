## RHFCN: Fully CNN-based Steganalysis of MP3 with Rich High-Pass Filtering

Building