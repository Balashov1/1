## Usage of batch scripts

### File description
ID      |   File                        |   Function
:-      |   :-                          |    :-
1       |   files_move_batch.bat        |   scripts for files movement
2       |   QMDCT_extraction_batch.bat  |   scripts for QMDCT coefficients
3       |   train_test_split_batch.bat  |   scripts for train and test dataset split

The batch scripts are just for data processing in batch, the usage is the same with the usage of python scripts.