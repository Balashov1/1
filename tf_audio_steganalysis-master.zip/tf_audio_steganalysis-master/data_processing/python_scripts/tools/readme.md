### File description
The usage of each encoder is shown as follows.
Encoder             |   Description
:-:      	        |    :-
encode.exe          |   lame encoder
encode_MP3Stego.exe |   MP3Stego encoder for MP3Stego cover and stego
encode_HCM.exe      |   HCM encoder for MP3Stego cover and stego
lame_qmdct.exe      |   QMDCT coefficients matrix extractor