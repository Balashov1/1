## File description

ID      |   File                    |   Function
:-      |   :-                      |    :-
01      |   dct_kernels             |   dct kernels for high-pass filtering (kernel size: 2,3,4,5,6,7,8)
02      |   filters.py              |   a script for the HPF function call
03      |   SRM_Kernels.npy         |   Spitial Rich Models for high-pass filtering