## File description

ID      |   File                    |   Function
:-      |   :-                      |    :-
01      |   arbitrary_size.py       |   basic modules of steganalysis with **arbitrary size**
02      |   densenet_block.py       |   basic modules of **dense net**
03      |   inception.py            |   basic modules of **multi-scale CNN**
04      |   resnet_block.py         |   basic modules of **resnet**